package edu.fatec.cliente.api.model;
 
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
 
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
 
@Entity
@Table(name="Usuario")
 
public class Usuario {	
	@Id
	@GeneratedValue
	private Integer id;	
	@Column(name="usuario")
	private String nome;	
	private String senha;
	private String palavraChave;
	private boolean tipo;
	

	public Usuario(Integer id, String nome, String senha, String palavraChave, boolean tipo) {
		super();
		this.id = id;
		this.nome = nome;
		this.senha = senha;
		this.palavraChave = palavraChave;
		this.tipo = tipo;
	}
	
	public Integer getId() {
		return id;
	}
	
	public void setId(Integer id) {
		this.id = id;
	}
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getSenha() {
		return senha;
	}
	
	public void setSenha(String senha) {
		this.senha = senha;
	}
	
	public String getPalavraChave() {
		return palavraChave;
	}
	
	public void setPalavraChave(String palavraChave) {
		this.palavraChave = palavraChave;
	}
	
	public boolean isTipo() {
		return tipo;
	}
	
	public void setTipo(boolean tipo) {
		this.tipo = tipo;
	}
	
	
 
}